# Aplicativo de gestão condominial — V1.3 (protótipo + base de integração)

## Conteúdo
- `index.html`: protótipo navegável com dados fictícios; ainda não conectado a autenticação ou banco.
- `livro-caixa-original.html`: HTML original preservado como referência.
- `schema.sql`: esquema inicial PostgreSQL/Supabase.
- `supabase/migrations/20261019_001_cobranca_caixa.sql`: tabelas e RLS para cobranças individualizadas e integração CAIXA; ajustar/revisar em ambiente de teste.
- `supabase/functions/caixa-cobranca/index.ts`: Edge Function protegida; valida autenticação/perfil e informa prontidão. Emissão/consulta/cancelamento ainda bloqueados.
- `docs/GUIA_INTEGRACAO_CAIXA.md`: solicitações ao gerente, segurança e roteiro de homologação.
- `docs/CONFIGURAR_UNIDADES.sql`: carga das oito unidades/frações; requer substituir UUID do condomínio.
- `ESPECIFICACAO_TECNICA_v1.3.md`: requisitos e estado da entrega.

## Estado atual — importante
Esta entrega **não é um sistema de produção** e **não emite boletos reais**. A interface permanece demonstrativa, sem login real ou persistência. A migração e a função de backend são base de implementação e precisam ser aplicadas/testadas em um projeto Supabase real. A emissão só poderá ser implementada após receber o manual vigente e confirmar canal, modalidade, credenciais e homologação do convênio da CAIXA.

## Próximos passos imediatos
1. Síndico solicita à CAIXA a confirmação de habilitação do WebService de cobrança e recebe manual vigente, WSDL/XSD, modalidade, carteira, código de beneficiário, autenticação e instruções de homologação.
2. Equipe técnica cria projeto Supabase de desenvolvimento, aplica primeiro `schema.sql` e depois a migração V1.3.
3. Configura os segredos de servidor no cofre do ambiente; nunca no HTML nem nesta conversa.
4. Cria condomínio, executa a carga das unidades após preencher o UUID e verifica soma das frações = `1.0000000`.
5. Implementa e testa o adaptador bancário específico, o registro de cobranças, retorno/baixa e conciliação idempotente.
6. Conecta o front-end à autenticação, RLS e funções de backend; executa testes de permissão por síndico, conselho e morador.
7. Homologa com a CAIXA antes de emissão real.

Consulte `docs/GUIA_INTEGRACAO_CAIXA.md` para a lista de perguntas ao gerente e testes de homologação.
