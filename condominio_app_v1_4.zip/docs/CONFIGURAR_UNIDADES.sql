-- Substitua o UUID abaixo pelo ID real do condomínio criado no banco.
-- Execute apenas uma vez e confira a convenção antes de liberar o sistema.
-- As frações somam exatamente 1,0000000.
with dados(identificacao, fracao_ideal) as (
  values
    ('01', 0.1125080::numeric(10,7)),
    ('02', 0.1114412::numeric(10,7)),
    ('101',0.1117246::numeric(10,7)),
    ('102',0.1127054::numeric(10,7)),
    ('201',0.1183161::numeric(10,7)),
    ('202',0.1127054::numeric(10,7)),
    ('301',0.1680773::numeric(10,7)),
    ('302',0.1525220::numeric(10,7))
)
insert into public.unidades (condominio_id, identificacao, fracao_ideal)
select 'SUBSTITUA-PELO-UUID-DO-CONDOMINIO'::uuid, identificacao, fracao_ideal
from dados
on conflict (condominio_id, identificacao) do update
set fracao_ideal = excluded.fracao_ideal;

-- Verificação obrigatória: deve retornar 1,0000000.
-- select sum(fracao_ideal) from public.unidades
-- where condominio_id = 'SUBSTITUA-PELO-UUID-DO-CONDOMINIO'::uuid and ativa;
